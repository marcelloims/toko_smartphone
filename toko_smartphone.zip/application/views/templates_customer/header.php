<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<title>PhonePedia</title>

<!-- Font Awesome Icons -->
<link rel="stylesheet" href="<?= base_url() ?>assets/plugins/fontawesome-free/css/all.min.css">
<!-- Font Awesome Icon 4.7.0 -->
<link rel="stylesheet" href="<?= base_url() ?>assets/font-awesome-470/css/font-awesome.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?= base_url() ?>assets/dist/css/adminlte.min.css">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">